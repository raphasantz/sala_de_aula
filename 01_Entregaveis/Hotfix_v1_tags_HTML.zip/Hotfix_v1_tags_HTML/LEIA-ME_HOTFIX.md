# Hotfix v1 — Checkpoint com tags HTML (Aula 6 em diante)

**Problema relatado:** "pagina inconsistente" — no checkpoint da Aula 6 (pergunta 2/3),
os botões de alternativa apareciam **vazios** (só os símbolos ▲ ◆ ● ■), faltavam
alternativas e o botão "Próxima" sumia.

**Causa (explicação simples):** as alternativas dessa pergunta *são* tags HTML:
`<head>`, `<title>`, `<body>`, `<meta>`. A versão **v1** (que ainda está no ar)
colava esse texto "solto" na página. O navegador, ao ler `<title>` no meio do
botão, achava que era um comando dele e **engolia** o texto — e como `<title>`
abre um elemento que só fecha com `</title>`, ele engolia **o resto da página
inteira** também (por isso sumiam as outras alternativas e o botão Próxima).
Não era problema do conteúdo, nem do celular/PC: era a página sem a proteção
que transforma tag em texto visível.

**Correção:** entrou a função `rich()` (a mesma proteção que a versão **v2** já
usa desde sempre): ela converte `<` de tags em texto (`&lt;`), mantendo só as
marcações permitidas (`<b>`, `<i>`, `<br>`...). Foram **6 pontos de uso**, todos
dentro do checkpoint (enunciado, alternativas, explicações/feedback).
**Mais nada mudou**: mesmo layout, mesmos dados, mesma API, mesmo login.

## O que tem neste pacote

| Caminho | Uso |
|---|---|
| `apps-nuvem/AulaViva_pi1_index.html` | substitui o arquivo homônimo no redserver (PI-I online) |
| `apps-nuvem/AulaViva_lp2_index.html` | substitui o arquivo homônimo no redserver (LP2 online) |
| `apps-offline/AulaViva_PI-I_offline.html` | offline v1 corrigido (PI-I) — laboratório/Kit Alunos |
| `apps-offline/AulaViva_LP2_offline.html` | offline v1 corrigido (LP2) — laboratório/Kit Alunos |
| `supabase-vercel/AulaViva_Kit_SoSupabase/aulaviva-pi1/index.html` | PI-I do kit **Só Supabase** (edge functions) |
| `supabase-vercel/AulaViva_Kit_SoSupabase/aulaviva-lp2/index.html` | LP2 do kit **Só Supabase** |
| `supabase-vercel/AulaViva_Kit_Vercel_Supabase/aulaviva-pi1/index.html` | PI-I do kit **Vercel + Supabase** |
| `supabase-vercel/AulaViva_Kit_Vercel_Supabase/aulaviva-lp2/index.html` | LP2 do kit **Vercel + Supabase** |
| `hotfix_tags_html.patch` | patch git opcional (aplica limpo em `master`) |
| `LEIA-ME_HOTFIX.md` | este arquivo |

> Os ZIPs `output/AulaViva_Kit_SoSupabase.zip` e `output/AulaViva_Kit_Vercel_Supabase.zip`
> **já saíram regravados com esses arquivos corrigidos dentro** — os arquivos avulsos
> acima existem só para o caso de o deploy já ter sido feito com a versão antiga.

## MD5 (conferir após copiar)

```
f942b18901b99c40e05d698882b99d11  apps-nuvem/AulaViva_pi1_index.html
ace7afa34f9ab73abf6e793b4696edf7  apps-nuvem/AulaViva_lp2_index.html
e189b51343292655deff152d1a80a3b9  apps-offline/AulaViva_PI-I_offline.html
4f3d1bc47495c48b404742aa0bdb6c06  apps-offline/AulaViva_LP2_offline.html
3cc3bac0b40d10d97310e93423762492  supabase-vercel/AulaViva_Kit_SoSupabase/aulaviva-pi1/index.html
6c6989e5efbc579f7adb26e4cffe2467  supabase-vercel/AulaViva_Kit_SoSupabase/aulaviva-lp2/index.html
daae8bf483a17b36d179cd7ff7a4f868  supabase-vercel/AulaViva_Kit_Vercel_Supabase/aulaviva-pi1/index.html
74788dc29974b998cf27c515ba82cb57  supabase-vercel/AulaViva_Kit_Vercel_Supabase/aulaviva-lp2/index.html
```

## Deploy no redserver (Rapha) — 2 minutos

```bash
scp apps-nuvem/AulaViva_pi1_index.html apps-nuvem/AulaViva_lp2_index.html \
    usuario@servidor:/caminho/do/redserver/apps-nuvem/
# no servidor:
md5sum apps-nuvem/AulaViva_pi1_index.html apps-nuvem/AulaViva_lp2_index.html
```

Não precisa reiniciar nada (é HTML estático). No navegador, **Ctrl+F5** para
burlar o cache.

### Offline (laboratório / Kit Alunos)
Substitua os dois arquivos `apps-offline/` nos PCs e/ou regenere o
`Kit_Alunos.zip` com eles.

### Via git (opcional, para ficar registrado)
```bash
git checkout -b feature/rapida-fix-tags-html master   # nunca direto no master
git apply hotfix_tags_html.patch
git commit -am "fix(aulaviva): alternativas de checkpoint com tags HTML aparecem como texto (rich)"
```

### Supabase / Vercel (a "segunda onda" do bug)
Depois do primeiro hotfix, apareceu **outra** página inconsistente com a mesma
cara (botões ▲ ◆ vazios). O diagnóstico mostrou que não era um bug novo: eram
os `index.html` dos kits **AulaViva_Kit_SoSupabase.zip** e
**AulaViva_Kit_Vercel_Supabase.zip**. Esses kits foram montados numa época em
que a base ainda era a v1 sem a proteção, e ficaram "congelados no tempo" —
ou seja: o remédio tinha chegado no redserver e no offline, mas não nesses
gêmeos da nuvem Supabase/Vercel.

Como corrigir (Rapha):
1. Se o deploy Supabase/Vercel **ainda não foi feito**: use os ZIPs novos
   (`output/AulaViva_Kit_SoSupabase.zip` / `AulaViva_Kit_Vercel_Supabase.zip`),
   que já contêm o `index.html` vacinado. Nada mais mudou nos kits.
2. Se **já foi feito**: substitua o `index.html` deployado de cada disciplina
   pelo arquivo avulso correspondente em `supabase-vercel/...` (confira o MD5
   acima). No Vercel: troque o arquivo no repositório/preview e redeploy.
   No Supabase: o `index.html` é estático — substitua onde ele estiver
   hospedado (Storage/site/pasta local dos alunos).
3. **Ctrl+F5** no navegador depois (cache).

### Rodada 3 — a pasta solta `deploy-supabase/` (raiz do "continuou quebrada")

O print que voltou da turma é **idêntico ao anterior** (mesmos pixels): ou seja,
o arquivo que o servidor Supabase entrega **não tinha sido trocado**. Investigando
o workspace, achei o culpado provável: além dos ZIPs dos kits, existe uma **pasta
solta** `deploy-supabase/aulaviva-{pi1,lp2}/` (gerada pelo
`material/build_deploy_supabase.py` numa época em que a base ainda era v1).
Se o upload pro Supabase foi feito **a partir dessa pasta**, subiu o arquivo
sem a vacina — e a página continua engolindo as alternativas.

Feito agora (rodada 3, `pr_work/hotfix/round3_deploy_supabase.py`):
- os dois `deploy-supabase/aulaviva-*/index.html` receberam as mesmas 9
  substituições do hotfix, **in place**, sem tocar em nenhum outro arquivo;
- resultado **byte a byte idêntico** aos arquivos vacinados do kit Só Supabase
  (MD5 `3cc3bac0…` pi1 e `6c6989e5…` lp2 — mesmos da tabela acima);
- os ZIPs `AulaViva_Kit_SoSupabase.zip` / `AulaViva_Kit_Vercel_Supabase.zip`
  **não mudaram** (já estavam vacinados desde a rodada 2).

**Ação (Rapha):** se o site Supabase foi publicado a partir da pasta
`deploy-supabase/`, **re-suba os dois `index.html` dela agora** (ou re-suba o
ZIP do kit inteiro). Depois Ctrl+F5 e refaça o teste da Aula 6.

## Ainda inconsistente na turma? Diagnóstico em 3 passos (Rapha)

**Passo 1 — o servidor está servindo o arquivo novo? (10 s)**
Na página quebrada: `Ctrl+U` (ver código-fonte) → `Ctrl+F` → digite
`function rich`.
- **Achou** → o arquivo no servidor JÁ é o vacinado; o problema é **cache**
  (passo 3).
- **Não achou** → o servidor ainda está com o arquivo **velado/antigo**:
  substitua pelo arquivo do hotfix (passo 2).

**Passo 2 — conferir o arquivo no servidor pelo MD5**
```bash
md5sum index.html   # no servidor / pasta de deploy
```
Compare com a tabela de MD5 acima. Diferente = arquivo antigo ainda no lugar.
Caminhos possíveis conforme o deploy: `redserver/apps-nuvem/`, pasta do kit
Só Supabase, pasta do kit Vercel, ou `deploy-supabase/aulaviva-*/`.

**Passo 3 — cache**
- Navegador: **Ctrl+F5** (ou aba anônima) — o print antigo pode ser só cache.
- Vercel: trocou o arquivo → **redeploy** (ou purge de cache do domínio).
- Supabase (Storage/site estático): re-suba o arquivo e teste em aba anônima.

**Como saber QUAL build a turma está vendo (pelo print):**
| Marca no topo | Build |
|---|---|
| botão 📔 Materiais + pill ☁ salvo, **sem** paginador | kit **Só Supabase** (v1) |
| **sem** botão Materiais, pill ☁ salvo, sem paginador | kit **Vercel + Supabase** (v1) |
| paginador ⏮  página ▶ ⏭ no rodapé | **v2** (já nasce vacinada) |

## Teste rápido (ngrok ou local)

1. Abrir o AulaViva PI-I → Módulo 2 → Aula 6 → checkpoint.
2. Pergunta 2/3 ("O conteúdo VISÍVEL da página fica dentro de:"): devem aparecer
   **4 alternativas com o texto visível**: `<head>`, `<title>`, `<body>`, `<meta>`.
3. Errar de propósito: o feedback mostra a correta com texto (`<body>`) e o
   botão "Próxima" aparece normalmente.
4. Pergunta 3/3 e as demais de HTML (Aulas 7, 8, 12, 13…) também com tags visíveis.
5. Conferir que o resto do app segue igual (login, progresso, materiais).

## Observação importante

A versão **v2** (branch `feature/rapida-aulaviva-v2`, PR_AulaViva_v2.zip) **já
nasce com essa proteção** — este hotfix existe só para consertar a **v1 que está
no ar hoje**, sem esperar o merge do PR. Quando a v2 for deployada, este hotfix
deixa de ser necessário (a v2 já inclui tudo).

Os kits Supabase/Vercel continuam sendo **v1 + este hotfix** (eles recebem o
sync da nuvem por cima do app v1). Se um dia migrarmos esses kits para a base
v2, o gerador (`material/build_deploy_supabase.py`) já verifica se a base tem
`rich()` e vacina automaticamente qualquer base v1 que encontrar.
